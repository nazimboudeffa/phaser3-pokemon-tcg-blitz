export const me1 =
  [
  {
    "id": "me1-1",
    "name": "Bulbasaur",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Grass"
    ],
    "evolvesTo": [
      "Ivysaur"
    ],
    "attacks": [
      {
        "name": "Bind Down",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": "During your opponent's next turn, the Defending Pokémon can't retreat."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "1",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      1
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/1.png",
      "large": "https://images.pokemontcg.io/me1/1_hires.png"
    }
  },
  {
    "id": "me1-2",
    "name": "Ivysaur",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "110",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Bulbasaur",
    "evolvesTo": [
      "Venusaur"
    ],
    "attacks": [
      {
        "name": "Razor Leaf",
        "cost": [
          "Grass",
          "Grass"
        ],
        "convertedEnergyCost": 2,
        "damage": "60",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "2",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      2
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/2.png",
      "large": "https://images.pokemontcg.io/me1/2_hires.png"
    }
  },
  {
    "id": "me1-3",
    "name": "Mega Venusaur ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2",
      "MEGA",
      "ex"
    ],
    "hp": "380",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Ivysaur",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "abilities": [
      {
        "name": "Solar Transfer",
        "text": "As often as you like during your turn, you may use this Ability. Move a Basic Grass Energy from 1 of your Pokémon to another of your Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Jungle Dump",
        "cost": [
          "Grass",
          "Grass",
          "Grass",
          "Grass"
        ],
        "convertedEnergyCost": 4,
        "damage": "240",
        "text": "Heal 30 damage from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "3",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      3
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/3.png",
      "large": "https://images.pokemontcg.io/me1/3_hires.png"
    }
  },
  {
    "id": "me1-4",
    "name": "Exeggcute",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "60",
    "types": [
      "Grass"
    ],
    "evolvesTo": [
      "Exeggutor"
    ],
    "attacks": [
      {
        "name": "Jam-Packed",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Search your deck for a Basic Grass Energy card and attach it to this Pokémon. Then, shuffle your deck."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "4",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      102
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/4.png",
      "large": "https://images.pokemontcg.io/me1/4_hires.png"
    }
  },
  {
    "id": "me1-5",
    "name": "Exeggutor",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "140",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Exeggcute",
    "attacks": [
      {
        "name": "Guard Press",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "During your opponent's next turn, this Pokémon takes 30 less damage from attacks (after applying Weakness and Resistance)."
      },
      {
        "name": "Stomping Wood",
        "cost": [
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "60+",
        "text": "This attack does 30 more damage for each Grass Energy attached to this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "5",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      103
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/5.png",
      "large": "https://images.pokemontcg.io/me1/5_hires.png"
    }
  },
  {
    "id": "me1-6",
    "name": "Tangela",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Grass"
    ],
    "evolvesTo": [
      "Tangrowth"
    ],
    "attacks": [
      {
        "name": "Poison Powder",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Your opponent's Active Pokémon is now Poisoned."
      },
      {
        "name": "Hook",
        "cost": [
          "Grass",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "6",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      114
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/6.png",
      "large": "https://images.pokemontcg.io/me1/6_hires.png"
    }
  },
  {
    "id": "me1-7",
    "name": "Tangrowth",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "150",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Tangela",
    "attacks": [
      {
        "name": "Absorb",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": "Heal 30 damage from this Pokémon."
      },
      {
        "name": "Pumped-Up Whip",
        "cost": [
          "Grass",
          "Grass",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 4,
        "damage": "120+",
        "text": "If this Pokémon has at least 2 extra Energy attached (in addition to this attack's cost), this attack does 140 more damage."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "7",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      465
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/7.png",
      "large": "https://images.pokemontcg.io/me1/7_hires.png"
    }
  },
  {
    "id": "me1-8",
    "name": "Chikorita",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Grass"
    ],
    "evolvesTo": [
      "Bayleef"
    ],
    "attacks": [
      {
        "name": "Razor Leaf",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "8",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      152
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/8.png",
      "large": "https://images.pokemontcg.io/me1/8_hires.png"
    }
  },
  {
    "id": "me1-9",
    "name": "Bayleef",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "110",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Chikorita",
    "evolvesTo": [
      "Meganium"
    ],
    "attacks": [
      {
        "name": "Push Down",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": "Switch out your opponent's Active Pokémon to the Bench. (Your opponent chooses the new Active Pokémon.)"
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "9",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      153
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/9.png",
      "large": "https://images.pokemontcg.io/me1/9_hires.png"
    }
  },
  {
    "id": "me1-10",
    "name": "Meganium",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "160",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Bayleef",
    "abilities": [
      {
        "name": "Wild Growth",
        "text": "Each Basic Grass Energy attached to all of your Pokémon provides GrassGrass Energy. The effect of Wild Growth doesn't stack.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Solar Beam",
        "cost": [
          "Grass",
          "Grass",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 4,
        "damage": "140",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "10",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      154
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/10.png",
      "large": "https://images.pokemontcg.io/me1/10_hires.png"
    }
  },
  {
    "id": "me1-11",
    "name": "Shuckle",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Grass"
    ],
    "abilities": [
      {
        "name": "Fermented Juice",
        "text": "Once during your turn, if this Pokémon has any Grass Energy attached, you may use this Ability. Heal 30 damage from 1 of your Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Rollout",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "11",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      213
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/11.png",
      "large": "https://images.pokemontcg.io/me1/11_hires.png"
    }
  },
  {
    "id": "me1-12",
    "name": "Celebi",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Grass"
    ],
    "attacks": [
      {
        "name": "Traverse Time",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Search your deck for up to 3 in any combination of Grass Pokémon and Stadium cards, reveal them, and put them into your hand. Then, shuffle your deck."
      },
      {
        "name": "Solar Cutter",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "12",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      251
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/12.png",
      "large": "https://images.pokemontcg.io/me1/12_hires.png"
    }
  },
  {
    "id": "me1-13",
    "name": "Seedot",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "60",
    "types": [
      "Grass"
    ],
    "evolvesTo": [
      "Nuzleaf"
    ],
    "attacks": [
      {
        "name": "Nap",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Heal 20 damage from this Pokémon."
      },
      {
        "name": "Seed Bomb",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "13",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      273
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/13.png",
      "large": "https://images.pokemontcg.io/me1/13_hires.png"
    }
  },
  {
    "id": "me1-14",
    "name": "Nuzleaf",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "100",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Seedot",
    "evolvesTo": [
      "Shiftry"
    ],
    "attacks": [
      {
        "name": "Pound",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": ""
      },
      {
        "name": "Low Kick",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "14",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      274
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/14.png",
      "large": "https://images.pokemontcg.io/me1/14_hires.png"
    }
  },
  {
    "id": "me1-15",
    "name": "Shiftry",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "160",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Nuzleaf",
    "attacks": [
      {
        "name": "Reversing Gust",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Flip a coin. If heads, choose 1 of your opponent's Pokémon. Shuffle that Pokémon and all attached cards into their deck."
      },
      {
        "name": "Perplex",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "100",
        "text": "Your opponent's Active Pokémon is now Confused."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "15",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      275
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/15.png",
      "large": "https://images.pokemontcg.io/me1/15_hires.png"
    }
  },
  {
    "id": "me1-16",
    "name": "Nincada",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "50",
    "types": [
      "Grass"
    ],
    "evolvesTo": [
      "Ninjask"
    ],
    "attacks": [
      {
        "name": "Scratch",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "16",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      290
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/16.png",
      "large": "https://images.pokemontcg.io/me1/16_hires.png"
    }
  },
  {
    "id": "me1-17",
    "name": "Ninjask",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "80",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Nincada",
    "evolvesTo": [
      "Shedinja"
    ],
    "abilities": [
      {
        "name": "Cast-Off Shell",
        "text": "Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Search your deck for a Shedinja and put it onto your Bench. Then, shuffle your deck.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "U-turn",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "90",
        "text": "Switch this Pokémon with 1 of your Benched Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "number": "17",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      291
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/17.png",
      "large": "https://images.pokemontcg.io/me1/17_hires.png"
    }
  },
  {
    "id": "me1-18",
    "name": "Dhelmise",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "120",
    "types": [
      "Grass"
    ],
    "attacks": [
      {
        "name": "Earthen Power",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30+",
        "text": "If you have a Stadium in play, this attack does 50 more damage."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "18",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      781
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/18.png",
      "large": "https://images.pokemontcg.io/me1/18_hires.png"
    }
  },
  {
    "id": "me1-19",
    "name": "Vulpix",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Fire"
    ],
    "evolvesTo": [
      "Ninetales"
    ],
    "attacks": [
      {
        "name": "Stampede",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Combustion",
        "cost": [
          "Fire",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "19",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      37
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/19.png",
      "large": "https://images.pokemontcg.io/me1/19_hires.png"
    }
  },
  {
    "id": "me1-20",
    "name": "Ninetales",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "120",
    "types": [
      "Fire"
    ],
    "evolvesFrom": "Vulpix",
    "attacks": [
      {
        "name": "Supernatural Shapeshifter",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Discard the top card of your deck, and if that card is a Supporter card, use the effect of that card as the effect of this attack."
      },
      {
        "name": "Combustion",
        "cost": [
          "Fire",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "60",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "20",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      38
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/20.png",
      "large": "https://images.pokemontcg.io/me1/20_hires.png"
    }
  },
  {
    "id": "me1-21",
    "name": "Numel",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Fire"
    ],
    "evolvesTo": [
      "Camerupt"
    ],
    "attacks": [
      {
        "name": "Call for Family",
        "cost": [
          "Fire"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Search your deck for up to 2 Basic Pokémon and put them onto your Bench. Then, shuffle your deck."
      },
      {
        "name": "Flare",
        "cost": [
          "Fire",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "21",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      322
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/21.png",
      "large": "https://images.pokemontcg.io/me1/21_hires.png"
    }
  },
  {
    "id": "me1-22",
    "name": "Mega Camerupt ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "340",
    "types": [
      "Fire"
    ],
    "evolvesFrom": "Numel",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Roasting Heat",
        "cost": [
          "Fire"
        ],
        "convertedEnergyCost": 1,
        "damage": "80+",
        "text": "If your opponent's Active Pokémon is Burned, this attack does 160 more damage."
      },
      {
        "name": "Volcanic Meteor",
        "cost": [
          "Fire",
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 4,
        "damage": "280",
        "text": "Discard 2 Energy from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "22",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      323
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/22.png",
      "large": "https://images.pokemontcg.io/me1/22_hires.png"
    }
  },
  {
    "id": "me1-23",
    "name": "Litleo",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Fire"
    ],
    "evolvesTo": [
      "Pyroar"
    ],
    "attacks": [
      {
        "name": "Flare",
        "cost": [
          "Fire",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "23",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      667
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/23.png",
      "large": "https://images.pokemontcg.io/me1/23_hires.png"
    }
  },
  {
    "id": "me1-24",
    "name": "Pyroar",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "130",
    "types": [
      "Fire"
    ],
    "evolvesFrom": "Litleo",
    "abilities": [
      {
        "name": "Intimidating Fang",
        "text": "As long as this Pokémon is in the Active Spot, attacks used by your opponent's Active Pokémon do 30 less damage (before applying Weakness and Resistance).",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Searing Flame",
        "cost": [
          "Fire",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "70",
        "text": "Your opponent's Active Pokémon is now Burned."
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "24",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      668
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/24.png",
      "large": "https://images.pokemontcg.io/me1/24_hires.png"
    }
  },
  {
    "id": "me1-25",
    "name": "Volcanion",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "130",
    "types": [
      "Fire"
    ],
    "attacks": [
      {
        "name": "Singe",
        "cost": [
          "Fire"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Your opponent's Active Pokémon is now Burned."
      },
      {
        "name": "Backfire",
        "cost": [
          "Fire",
          "Fire",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "130",
        "text": "Put 2 Fire Energy attached to this Pokémon into your hand."
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "25",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      721
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/25.png",
      "large": "https://images.pokemontcg.io/me1/25_hires.png"
    }
  },
  {
    "id": "me1-26",
    "name": "Scorbunny",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Fire"
    ],
    "evolvesTo": [
      "Raboot"
    ],
    "attacks": [
      {
        "name": "Wild Kick",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "Flip a coin. If tails, this attack does nothing."
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "26",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      813
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/26.png",
      "large": "https://images.pokemontcg.io/me1/26_hires.png"
    }
  },
  {
    "id": "me1-27",
    "name": "Raboot",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "100",
    "types": [
      "Fire"
    ],
    "evolvesFrom": "Scorbunny",
    "evolvesTo": [
      "Cinderace"
    ],
    "attacks": [
      {
        "name": "Jumping Kick",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "This attack does 40 damage to 1 of your opponent's Pokémon. (Don't apply Weakness and Resistance for Benched Pokémon.)"
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "27",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      814
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/27.png",
      "large": "https://images.pokemontcg.io/me1/27_hires.png"
    }
  },
  {
    "id": "me1-28",
    "name": "Cinderace",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "160",
    "types": [
      "Fire"
    ],
    "evolvesFrom": "Raboot",
    "abilities": [
      {
        "name": "Explosiveness",
        "text": "If this Pokémon is in your hand when you are setting up to play, you may put it face down in the Active Spot.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Turbo Flare",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "50",
        "text": "Search your deck for up to 3 Basic Energy cards and attach them to your Benched Pokémon in any way you like. Then, shuffle your deck."
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "number": "28",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      815
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/28.png",
      "large": "https://images.pokemontcg.io/me1/28_hires.png"
    }
  },
  {
    "id": "me1-29",
    "name": "Sizzlipede",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Fire"
    ],
    "evolvesTo": [
      "Centiskorch"
    ],
    "attacks": [
      {
        "name": "Ram",
        "cost": [
          "Fire"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Combustion",
        "cost": [
          "Fire",
          "Fire",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "50",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "29",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      850
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/29.png",
      "large": "https://images.pokemontcg.io/me1/29_hires.png"
    }
  },
  {
    "id": "me1-30",
    "name": "Centiskorch",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "140",
    "types": [
      "Fire"
    ],
    "evolvesFrom": "Sizzlipede",
    "attacks": [
      {
        "name": "Coiling Crush",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": "Flip 2 coins. For each heads, discard an Energy from your opponent's Active Pokémon."
      },
      {
        "name": "Heat Crawler",
        "cost": [
          "Fire",
          "Fire",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 4,
        "damage": "140",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "30",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      851
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/30.png",
      "large": "https://images.pokemontcg.io/me1/30_hires.png"
    }
  },
  {
    "id": "me1-31",
    "name": "Chi-Yu",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "110",
    "types": [
      "Fire"
    ],
    "attacks": [
      {
        "name": "Scorching Earth",
        "cost": [
          "Fire"
        ],
        "convertedEnergyCost": 1,
        "damage": "40",
        "text": "If your opponent has a Stadium in play, discard it. If you do, your opponent can't play any Stadium cards from their hand during their next turn."
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "31",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      1004
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/31.png",
      "large": "https://images.pokemontcg.io/me1/31_hires.png"
    }
  },
  {
    "id": "me1-32",
    "name": "Mantine",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "110",
    "types": [
      "Water"
    ],
    "attacks": [
      {
        "name": "Call for Family",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Search your deck for up to 2 Basic Pokémon and put them onto your Bench. Then, shuffle your deck."
      },
      {
        "name": "Waterfall",
        "cost": [
          "Water",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "32",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      226
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/32.png",
      "large": "https://images.pokemontcg.io/me1/32_hires.png"
    }
  },
  {
    "id": "me1-33",
    "name": "Corphish",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Water"
    ],
    "evolvesTo": [
      "Crawdaunt"
    ],
    "attacks": [
      {
        "name": "Vise Grip",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Take Down",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": "This Pokémon also does 10 damage to itself."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "33",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      341
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/33.png",
      "large": "https://images.pokemontcg.io/me1/33_hires.png"
    }
  },
  {
    "id": "me1-34",
    "name": "Kyogre",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "150",
    "types": [
      "Water"
    ],
    "attacks": [
      {
        "name": "Riptide",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "20×",
        "text": "This attack does 20 damage for each Basic Water Energy card in your discard pile. Then, shuffle those cards into your deck."
      },
      {
        "name": "Swirling Waves",
        "cost": [
          "Water",
          "Water",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "130",
        "text": "Discard 2 Energy from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "34",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      382
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/34.png",
      "large": "https://images.pokemontcg.io/me1/34_hires.png"
    }
  },
  {
    "id": "me1-35",
    "name": "Snover",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "90",
    "types": [
      "Water"
    ],
    "evolvesTo": [
      "Abomasnow"
    ],
    "attacks": [
      {
        "name": "Beat",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Icy Snow",
        "cost": [
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Metal",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "35",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      459
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/35.png",
      "large": "https://images.pokemontcg.io/me1/35_hires.png"
    }
  },
  {
    "id": "me1-36",
    "name": "Mega Abomasnow ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "350",
    "types": [
      "Water"
    ],
    "evolvesFrom": "Snover",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Hammer-lanche",
        "cost": [
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 2,
        "damage": "100×",
        "text": "Discard the top 6 cards of your deck, and this attack does 100 damage for each Basic Water Energy card that you discarded in this way."
      },
      {
        "name": "Frost Barrier",
        "cost": [
          "Water",
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 3,
        "damage": "200",
        "text": "During your opponent's next turn, this Pokémon takes 30 less damage from attacks (after applying Weakness and Resistance)."
      }
    ],
    "weaknesses": [
      {
        "type": "Metal",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "36",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      460
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/36.png",
      "large": "https://images.pokemontcg.io/me1/36_hires.png"
    }
  },
  {
    "id": "me1-37",
    "name": "Clauncher",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Water"
    ],
    "evolvesTo": [
      "Clawitzer"
    ],
    "attacks": [
      {
        "name": "Wave Splash",
        "cost": [
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "37",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      692
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/37.png",
      "large": "https://images.pokemontcg.io/me1/37_hires.png"
    }
  },
  {
    "id": "me1-38",
    "name": "Clawitzer",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "130",
    "types": [
      "Water"
    ],
    "evolvesFrom": "Clauncher",
    "abilities": [
      {
        "name": "Fall Back to Reload",
        "text": "Once during your turn, when this Pokémon moves from the Active Spot to your Bench, you may use this Ability. Attach up to 2 Basic Water Energy cards from your hand to this Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Aqua Launcher",
        "cost": [
          "Water",
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 3,
        "damage": "210",
        "text": "Discard all Energy from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "38",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      693
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/38.png",
      "large": "https://images.pokemontcg.io/me1/38_hires.png"
    }
  },
  {
    "id": "me1-39",
    "name": "Sobble",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Water"
    ],
    "evolvesTo": [
      "Drizzile"
    ],
    "attacks": [
      {
        "name": "Surprise Attack",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "Flip a coin. If tails, this attack does nothing."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "39",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      816
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/39.png",
      "large": "https://images.pokemontcg.io/me1/39_hires.png"
    }
  },
  {
    "id": "me1-40",
    "name": "Drizzile",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "100",
    "types": [
      "Water"
    ],
    "evolvesFrom": "Sobble",
    "evolvesTo": [
      "Inteleon"
    ],
    "attacks": [
      {
        "name": "Double Stab",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "30×",
        "text": "Flip 2 coins. This attack does 30 damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "40",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      817
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/40.png",
      "large": "https://images.pokemontcg.io/me1/40_hires.png"
    }
  },
  {
    "id": "me1-41",
    "name": "Inteleon",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "150",
    "types": [
      "Water"
    ],
    "evolvesFrom": "Drizzile",
    "attacks": [
      {
        "name": "Bring Down",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Choose a Pokémon in play (yours or your opponent's) that has the least HP remaining, except for this Pokémon, and it is Knocked Out."
      },
      {
        "name": "Water Shot",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "110",
        "text": "Discard an Energy from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "41",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      818
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/41.png",
      "large": "https://images.pokemontcg.io/me1/41_hires.png"
    }
  },
  {
    "id": "me1-42",
    "name": "Snom",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "50",
    "types": [
      "Water"
    ],
    "evolvesTo": [
      "Frosmoth"
    ],
    "attacks": [
      {
        "name": "Hide",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Flip a coin. If heads, during your opponent's next turn, prevent all damage from and effects of attacks done to this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Metal",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "42",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      872
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/42.png",
      "large": "https://images.pokemontcg.io/me1/42_hires.png"
    }
  },
  {
    "id": "me1-43",
    "name": "Frosmoth",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "110",
    "types": [
      "Water"
    ],
    "evolvesFrom": "Snom",
    "attacks": [
      {
        "name": "Chilling Wings",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "This attack does 20 damage to each of your opponent's Pokémon. (Don't apply Weakness and Resistance for Benched Pokémon.) Your opponent's Active Pokémon is now Asleep."
      }
    ],
    "weaknesses": [
      {
        "type": "Metal",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "43",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      873
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/43.png",
      "large": "https://images.pokemontcg.io/me1/43_hires.png"
    }
  },
  {
    "id": "me1-44",
    "name": "Eiscue",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "110",
    "types": [
      "Water"
    ],
    "attacks": [
      {
        "name": "Freezing Headbutt",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": "Flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed."
      },
      {
        "name": "Tackle",
        "cost": [
          "Water",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "90",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Metal",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "44",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      875
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/44.png",
      "large": "https://images.pokemontcg.io/me1/44_hires.png"
    }
  },
  {
    "id": "me1-45",
    "name": "Magnemite",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Lightning"
    ],
    "evolvesTo": [
      "Magneton"
    ],
    "attacks": [
      {
        "name": "Beam",
        "cost": [
          "Lightning"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "45",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      81
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/45.png",
      "large": "https://images.pokemontcg.io/me1/45_hires.png"
    }
  },
  {
    "id": "me1-46",
    "name": "Magneton",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "90",
    "types": [
      "Lightning"
    ],
    "evolvesFrom": "Magnemite",
    "evolvesTo": [
      "Magnezone"
    ],
    "attacks": [
      {
        "name": "Thunder Shock",
        "cost": [
          "Lightning"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "Flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "46",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      82
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/46.png",
      "large": "https://images.pokemontcg.io/me1/46_hires.png"
    }
  },
  {
    "id": "me1-47",
    "name": "Magnezone",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "160",
    "types": [
      "Lightning"
    ],
    "evolvesFrom": "Magneton",
    "attacks": [
      {
        "name": "Upper Spark",
        "cost": [
          "Lightning"
        ],
        "convertedEnergyCost": 1,
        "damage": "50+",
        "text": "If this Pokémon evolved from Magneton during this turn, this attack does 120 more damage."
      },
      {
        "name": "Flashing Bolt",
        "cost": [
          "Lightning",
          "Lightning"
        ],
        "convertedEnergyCost": 2,
        "damage": "160",
        "text": "During your next turn, this Pokémon can't use Flashing Bolt."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "47",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      462
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/47.png",
      "large": "https://images.pokemontcg.io/me1/47_hires.png"
    }
  },
  {
    "id": "me1-48",
    "name": "Raikou",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "120",
    "types": [
      "Lightning"
    ],
    "attacks": [
      {
        "name": "Electro Fall",
        "cost": [
          "Lightning",
          "Lightning"
        ],
        "convertedEnergyCost": 2,
        "damage": "30+",
        "text": "If you have at least 4 Lightning Energy in play, this attack does 90 more damage."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "48",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      243
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/48.png",
      "large": "https://images.pokemontcg.io/me1/48_hires.png"
    }
  },
  {
    "id": "me1-49",
    "name": "Electrike",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Lightning"
    ],
    "evolvesTo": [
      "Manectric"
    ],
    "attacks": [
      {
        "name": "Thunder Jolt",
        "cost": [
          "Lightning"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "This Pokémon also does 10 damage to itself."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "49",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      309
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/49.png",
      "large": "https://images.pokemontcg.io/me1/49_hires.png"
    }
  },
  {
    "id": "me1-50",
    "name": "Mega Manectric ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "330",
    "types": [
      "Lightning"
    ],
    "evolvesFrom": "Electrike",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Flash Ray",
        "cost": [
          "Lightning",
          "Lightning"
        ],
        "convertedEnergyCost": 2,
        "damage": "120",
        "text": "During your opponent's next turn, prevent all damage done to this Pokémon by attacks from Basic Pokémon."
      },
      {
        "name": "Riotous Blasting",
        "cost": [
          "Lightning",
          "Lightning",
          "Lightning"
        ],
        "convertedEnergyCost": 3,
        "damage": "200+",
        "text": "You may discard all Energy from this Pokémon and have this attack do 130 more damage."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "number": "50",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      310
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/50.png",
      "large": "https://images.pokemontcg.io/me1/50_hires.png"
    }
  },
  {
    "id": "me1-51",
    "name": "Pachirisu",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Lightning"
    ],
    "attacks": [
      {
        "name": "Electrified Incisors",
        "cost": [
          "Lightning"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": "During your opponent's next turn, whenever they attach an Energy card from their hand to the Defending Pokémon, place 8 damage counters on that Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "51",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      417
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/51.png",
      "large": "https://images.pokemontcg.io/me1/51_hires.png"
    }
  },
  {
    "id": "me1-52",
    "name": "Helioptile",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Lightning"
    ],
    "evolvesTo": [
      "Heliolisk"
    ],
    "attacks": [
      {
        "name": "Double Scratch",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10×",
        "text": "Flip 2 coins. This attack does 10 damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "52",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      694
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/52.png",
      "large": "https://images.pokemontcg.io/me1/52_hires.png"
    }
  },
  {
    "id": "me1-53",
    "name": "Heliolisk",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "120",
    "types": [
      "Lightning"
    ],
    "evolvesFrom": "Helioptile",
    "attacks": [
      {
        "name": "Dazzle Blast",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": "Your opponent's Active Pokémon is now Confused."
      },
      {
        "name": "Head Bolt",
        "cost": [
          "Lightning",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "70",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "53",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      695
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/53.png",
      "large": "https://images.pokemontcg.io/me1/53_hires.png"
    }
  },
  {
    "id": "me1-54",
    "name": "Abra",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "50",
    "types": [
      "Psychic"
    ],
    "evolvesTo": [
      "Kadabra"
    ],
    "attacks": [
      {
        "name": "Teleportation Attack",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": "Switch this Pokémon with 1 of your Benched Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "54",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      63
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/54.png",
      "large": "https://images.pokemontcg.io/me1/54_hires.png"
    }
  },
  {
    "id": "me1-55",
    "name": "Kadabra",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "80",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Abra",
    "evolvesTo": [
      "Alakazam"
    ],
    "abilities": [
      {
        "name": "Psychic Draw",
        "text": "Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Draw 2 cards.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Super Psy Bolt",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "55",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      64
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/55.png",
      "large": "https://images.pokemontcg.io/me1/55_hires.png"
    }
  },
  {
    "id": "me1-56",
    "name": "Alakazam",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "140",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Kadabra",
    "abilities": [
      {
        "name": "Psychic Draw",
        "text": "Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Draw 3 cards.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Powerful Hand",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Place 2 damage counters on your opponent's Active Pokémon for each card in your hand."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "56",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      65
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/56.png",
      "large": "https://images.pokemontcg.io/me1/56_hires.png"
    }
  },
  {
    "id": "me1-57",
    "name": "Jynx",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "110",
    "types": [
      "Psychic"
    ],
    "attacks": [
      {
        "name": "Psychic",
        "cost": [
          "Psychic",
          "Psychic"
        ],
        "convertedEnergyCost": 2,
        "damage": "30+",
        "text": "This attack does 30 more damage for each Energy attached to your opponent's Active Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "57",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      124
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/57.png",
      "large": "https://images.pokemontcg.io/me1/57_hires.png"
    }
  },
  {
    "id": "me1-58",
    "name": "Ralts",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Psychic"
    ],
    "evolvesTo": [
      "Kirlia"
    ],
    "attacks": [
      {
        "name": "Collect",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Draw a card."
      },
      {
        "name": "Headbutt",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "58",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      280
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/58.png",
      "large": "https://images.pokemontcg.io/me1/58_hires.png"
    }
  },
  {
    "id": "me1-59",
    "name": "Kirlia",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "100",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Ralts",
    "evolvesTo": [
      "Gardevoir",
      "Gallade"
    ],
    "attacks": [
      {
        "name": "Call Sign",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Search your deck for up to 3 Pokémon, reveal them, and put them into your hand. Then, shuffle your deck."
      },
      {
        "name": "Psyshot",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "59",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      281
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/59.png",
      "large": "https://images.pokemontcg.io/me1/59_hires.png"
    }
  },
  {
    "id": "me1-60",
    "name": "Mega Gardevoir ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2",
      "MEGA",
      "ex"
    ],
    "hp": "360",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Kirlia",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Overflowing Wishes",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "For each of your Benched Pokémon, search your deck for a Basic Psychic Energy card and attach it to that Pokémon. Then, shuffle your deck."
      },
      {
        "name": "Mega Symphonia",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "50×",
        "text": "This attack does 50 damage for each Psychic Energy attached to all of your Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "60",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      282
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/60.png",
      "large": "https://images.pokemontcg.io/me1/60_hires.png"
    }
  },
  {
    "id": "me1-61",
    "name": "Shedinja",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "60",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Nincada",
    "abilities": [
      {
        "name": "Fragile Husk",
        "text": "If this Pokémon is Knocked Out by damage from an attack from your opponent's Pokémon ex, your opponent can't take any Prize cards for it.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Damage Beat",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "20×",
        "text": "This attack does 20 damage for each damage counter on your opponent's Active Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "number": "61",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      292
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/61.png",
      "large": "https://images.pokemontcg.io/me1/61_hires.png"
    }
  },
  {
    "id": "me1-62",
    "name": "Spoink",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Psychic"
    ],
    "evolvesTo": [
      "Grumpig"
    ],
    "attacks": [
      {
        "name": "Triple Spin",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "10×",
        "text": "Flip 3 coins. This attack does 10 damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "62",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      325
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/62.png",
      "large": "https://images.pokemontcg.io/me1/62_hires.png"
    }
  },
  {
    "id": "me1-63",
    "name": "Grumpig",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "120",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Spoink",
    "abilities": [
      {
        "name": "Energized Steps",
        "text": "Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Look at the top 4 cards of your deck and attach any number of Basic Energy cards you find there to your Pokémon in any way you like. Shuffle the other cards back into your deck.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Psychic Sphere",
        "cost": [
          "Psychic",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "60",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "63",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      326
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/63.png",
      "large": "https://images.pokemontcg.io/me1/63_hires.png"
    }
  },
  {
    "id": "me1-64",
    "name": "Xerneas",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "120",
    "types": [
      "Psychic"
    ],
    "attacks": [
      {
        "name": "Geo Gate",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Search your deck for up to 3 Basic Psychic Pokémon and put them onto your Bench. Then, shuffle your deck."
      },
      {
        "name": "Bright Horns",
        "cost": [
          "Psychic",
          "Psychic",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "120",
        "text": "During your next turn, this Pokémon can't use Bright Horns."
      }
    ],
    "weaknesses": [
      {
        "type": "Metal",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "64",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      716
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/64.png",
      "large": "https://images.pokemontcg.io/me1/64_hires.png"
    }
  },
  {
    "id": "me1-65",
    "name": "Greavard",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Psychic"
    ],
    "attacks": [
      {
        "name": "Stampede",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Take Down",
        "cost": [
          "Psychic",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "40",
        "text": "This Pokémon also does 10 damage to itself."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "65",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      971
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/65.png",
      "large": "https://images.pokemontcg.io/me1/65_hires.png"
    }
  },
  {
    "id": "me1-66",
    "name": "Houndstone",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "140",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Greavard",
    "attacks": [
      {
        "name": "Horrifying Bite",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "Flip a coin until you get tails. For each heads, choose a random card from your opponent's hand. Your opponent reveals those cards and shuffles them into their deck."
      },
      {
        "name": "Hammer In",
        "cost": [
          "Psychic",
          "Psychic",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "130",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "66",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      972
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/66.png",
      "large": "https://images.pokemontcg.io/me1/66_hires.png"
    }
  },
  {
    "id": "me1-67",
    "name": "Gimmighoul",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Psychic"
    ],
    "attacks": [
      {
        "name": "Slap",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "67",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      999
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/67.png",
      "large": "https://images.pokemontcg.io/me1/67_hires.png"
    }
  },
  {
    "id": "me1-68",
    "name": "Sandshrew",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Fighting"
    ],
    "evolvesTo": [
      "Sandslash"
    ],
    "attacks": [
      {
        "name": "Dig Claws",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Mud-Slap",
        "cost": [
          "Fighting",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "68",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      27
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/68.png",
      "large": "https://images.pokemontcg.io/me1/68_hires.png"
    }
  },
  {
    "id": "me1-69",
    "name": "Sandslash",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "120",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Sandshrew",
    "attacks": [
      {
        "name": "Sand Attack",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": "During your opponent's next turn, if the Defending Pokémon tries to use an attack, your opponent flips a coin. If tails, that attack doesn't happen."
      },
      {
        "name": "Mud Shot",
        "cost": [
          "Fighting",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "100",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "69",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      28
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/69.png",
      "large": "https://images.pokemontcg.io/me1/69_hires.png"
    }
  },
  {
    "id": "me1-70",
    "name": "Onix",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "120",
    "types": [
      "Fighting"
    ],
    "evolvesTo": [
      "Steelix"
    ],
    "attacks": [
      {
        "name": "Bind",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": "Flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed."
      },
      {
        "name": "Strength",
        "cost": [
          "Colorless",
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 4,
        "damage": "100",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "70",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      95
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/70.png",
      "large": "https://images.pokemontcg.io/me1/70_hires.png"
    }
  },
  {
    "id": "me1-71",
    "name": "Tyrogue",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "30",
    "types": [
      "Fighting"
    ],
    "evolvesTo": [
      "Hitmonlee",
      "Hitmonchan",
      "Hitmontop"
    ],
    "attacks": [
      {
        "name": "Pow-Pow Punching",
        "cost": [
          "Free"
        ],
        "convertedEnergyCost": 1,
        "damage": "10+",
        "text": "Flip a coin until you get tails. This attack does 30 more damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "number": "71",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      236
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/71.png",
      "large": "https://images.pokemontcg.io/me1/71_hires.png"
    }
  },
  {
    "id": "me1-72",
    "name": "Makuhita",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Fighting"
    ],
    "evolvesTo": [
      "Hariyama"
    ],
    "attacks": [
      {
        "name": "Corkscrew Punch",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Confront",
        "cost": [
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "72",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      296
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/72.png",
      "large": "https://images.pokemontcg.io/me1/72_hires.png"
    }
  },
  {
    "id": "me1-73",
    "name": "Hariyama",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "150",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Makuhita",
    "abilities": [
      {
        "name": "Heave-Ho Catcher",
        "text": "Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Switch in 1 of your opponent's Benched Pokémon to the Active Spot.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Wild Press",
        "cost": [
          "Fighting",
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 3,
        "damage": "210",
        "text": "This Pokémon also does 70 damage to itself."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "73",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      297
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/73.png",
      "large": "https://images.pokemontcg.io/me1/73_hires.png"
    }
  },
  {
    "id": "me1-74",
    "name": "Lunatone",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "110",
    "types": [
      "Fighting"
    ],
    "abilities": [
      {
        "name": "Lunar Cycle",
        "text": "Once during your turn, if you have Solrock in play, you may discard a Basic Fighting Energy card from your hand in order to use this Ability. Draw 3 cards. You can't use more than 1 Lunar Cycle Ability each turn.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Power Gem",
        "cost": [
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "74",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      337
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/74.png",
      "large": "https://images.pokemontcg.io/me1/74_hires.png"
    }
  },
  {
    "id": "me1-75",
    "name": "Solrock",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "110",
    "types": [
      "Fighting"
    ],
    "attacks": [
      {
        "name": "Cosmic Beam",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "70",
        "text": "If you don't have Lunatone on your Bench, this attack does nothing. This attack's damage isn't affected by Weakness or Resistance."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "75",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      338
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/75.png",
      "large": "https://images.pokemontcg.io/me1/75_hires.png"
    }
  },
  {
    "id": "me1-76",
    "name": "Riolu",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Fighting"
    ],
    "evolvesTo": [
      "Lucario"
    ],
    "attacks": [
      {
        "name": "Accelerating Stab",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "During your next turn, this Pokémon can't use Accelerating Stab."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "76",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      447
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/76.png",
      "large": "https://images.pokemontcg.io/me1/76_hires.png"
    }
  },
  {
    "id": "me1-77",
    "name": "Mega Lucario ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "340",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Riolu",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Aura Jab",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "130",
        "text": "Attach up to 3 Basic Fighting Energy cards from your discard pile to your Benched Pokémon in any way you like."
      },
      {
        "name": "Mega Brave",
        "cost": [
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 2,
        "damage": "270",
        "text": "During your next turn, this Pokémon can't use Mega Brave."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "77",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      448
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/77.png",
      "large": "https://images.pokemontcg.io/me1/77_hires.png"
    }
  },
  {
    "id": "me1-78",
    "name": "Croagunk",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Fighting"
    ],
    "evolvesTo": [
      "Toxicroak"
    ],
    "attacks": [
      {
        "name": "Smack",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "78",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      453
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/78.png",
      "large": "https://images.pokemontcg.io/me1/78_hires.png"
    }
  },
  {
    "id": "me1-79",
    "name": "Toxicroak",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "130",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Croagunk",
    "attacks": [
      {
        "name": "Reckless Charge",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "70",
        "text": "This Pokémon also does 20 damage to itself."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "79",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      454
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/79.png",
      "large": "https://images.pokemontcg.io/me1/79_hires.png"
    }
  },
  {
    "id": "me1-80",
    "name": "Marshadow",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "90",
    "types": [
      "Fighting"
    ],
    "attacks": [
      {
        "name": "Shadowy Side Kick",
        "cost": [
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 2,
        "damage": "60",
        "text": "If your opponent's Pokémon is Knocked Out by damage from this attack, during your opponent's next turn, prevent all damage from and effects of attacks done to this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "80",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      802
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/80.png",
      "large": "https://images.pokemontcg.io/me1/80_hires.png"
    }
  },
  {
    "id": "me1-81",
    "name": "Stonjourner",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "130",
    "types": [
      "Fighting"
    ],
    "attacks": [
      {
        "name": "Stony Kick",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": "This attack also does 20 damage to 1 of your opponent's Benched Pokémon. (Don't apply Weakness and Resistance for Benched Pokémon.)"
      },
      {
        "name": "Boundless Power",
        "cost": [
          "Fighting",
          "Fighting",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "140",
        "text": "During your next turn, this Pokémon can't use attacks."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "81",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      874
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/81.png",
      "large": "https://images.pokemontcg.io/me1/81_hires.png"
    }
  },
  {
    "id": "me1-82",
    "name": "Nacli",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Fighting"
    ],
    "attacks": [
      {
        "name": "Ram",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "82",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      932
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/82.png",
      "large": "https://images.pokemontcg.io/me1/82_hires.png"
    }
  },
  {
    "id": "me1-83",
    "name": "Naclstack",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "110",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Nacli",
    "attacks": [
      {
        "name": "Rock Hurl",
        "cost": [
          "Fighting",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": "This attack's damage isn't affected by Resistance."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "83",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      933
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/83.png",
      "large": "https://images.pokemontcg.io/me1/83_hires.png"
    }
  },
  {
    "id": "me1-84",
    "name": "Garganacl",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "180",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Naclstack",
    "abilities": [
      {
        "name": "Powerful a-Salt",
        "text": "Attacks used by your Fighting Pokémon do 30 more damage to your opponent's Active Pokémon (before applying Weakness and Resistance).",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Hammer In",
        "cost": [
          "Fighting",
          "Fighting",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "130",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "84",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      934
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/84.png",
      "large": "https://images.pokemontcg.io/me1/84_hires.png"
    }
  },
  {
    "id": "me1-85",
    "name": "Crawdaunt",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "130",
    "types": [
      "Darkness"
    ],
    "evolvesFrom": "Corphish",
    "attacks": [
      {
        "name": "Vise Grip",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": ""
      },
      {
        "name": "Cutting Riposte",
        "cost": [
          "Darkness",
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "130",
        "text": "If this Pokémon has any damage counters on it, this attack can be used for Darkness."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "85",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      342
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/85.png",
      "large": "https://images.pokemontcg.io/me1/85_hires.png"
    }
  },
  {
    "id": "me1-86",
    "name": "Mega Absol ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "280",
    "types": [
      "Darkness"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Terminal Period",
        "cost": [
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "",
        "text": "If your opponent's Active Pokémon has exactly 6 damage counters on it, that Pokémon is Knocked Out."
      },
      {
        "name": "Claw of Darkness",
        "cost": [
          "Darkness",
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "200",
        "text": "Your opponent reveals their hand, and you discard a card you find there."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "86",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      359
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/86.png",
      "large": "https://images.pokemontcg.io/me1/86_hires.png"
    }
  },
  {
    "id": "me1-87",
    "name": "Spiritomb",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Darkness"
    ],
    "abilities": [
      {
        "name": "Spiteful Swirl",
        "text": "If your Active Darkness Pokémon is damaged by an attack from your opponent's Pokémon (even if your Active Darkness Pokémon is Knocked Out), place 1 damage counter on the Attacking Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Mountain Breaker",
        "cost": [
          "Darkness"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": "Discard the top card of your opponent's deck."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "87",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      442
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/87.png",
      "large": "https://images.pokemontcg.io/me1/87_hires.png"
    }
  },
  {
    "id": "me1-88",
    "name": "Yveltal",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "110",
    "types": [
      "Darkness"
    ],
    "attacks": [
      {
        "name": "Clutch",
        "cost": [
          "Darkness"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": "During your opponent's next turn, the Defending Pokémon can't retreat."
      },
      {
        "name": "Dark Feather",
        "cost": [
          "Darkness",
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "110",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "number": "88",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      717
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/88.png",
      "large": "https://images.pokemontcg.io/me1/88_hires.png"
    }
  },
  {
    "id": "me1-89",
    "name": "Nickit",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Darkness"
    ],
    "evolvesTo": [
      "Thievul"
    ],
    "attacks": [
      {
        "name": "Darkness Fang",
        "cost": [
          "Darkness"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "89",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      827
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/89.png",
      "large": "https://images.pokemontcg.io/me1/89_hires.png"
    }
  },
  {
    "id": "me1-90",
    "name": "Thievul",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "120",
    "types": [
      "Darkness"
    ],
    "evolvesFrom": "Nickit",
    "attacks": [
      {
        "name": "Greedy Hunt",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": "You may draw cards until you have 6 cards in your hand."
      },
      {
        "name": "Pitch-Black Fangs",
        "cost": [
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "60",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "90",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      828
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/90.png",
      "large": "https://images.pokemontcg.io/me1/90_hires.png"
    }
  },
  {
    "id": "me1-91",
    "name": "Shroodle",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "60",
    "types": [
      "Darkness"
    ],
    "attacks": [
      {
        "name": "Poison Jab",
        "cost": [
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": "Your opponent's Active Pokémon is now Poisoned."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "91",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      944
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/91.png",
      "large": "https://images.pokemontcg.io/me1/91_hires.png"
    }
  },
  {
    "id": "me1-92",
    "name": "Grafaiai",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "100",
    "types": [
      "Darkness"
    ],
    "evolvesFrom": "Shroodle",
    "attacks": [
      {
        "name": "Miraculous Paint",
        "cost": [
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "90",
        "text": "Flip a coin. If heads, choose a Special Condition. Your opponent's Active Pokémon is now affected by that Special Condition."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "92",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      945
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/92.png",
      "large": "https://images.pokemontcg.io/me1/92_hires.png"
    }
  },
  {
    "id": "me1-93",
    "name": "Steelix",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "200",
    "types": [
      "Metal"
    ],
    "evolvesFrom": "Onix",
    "attacks": [
      {
        "name": "Welcoming Tail",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "40+",
        "text": "If you have exactly 6 Prize cards remaining, this attack does 200 more damage."
      },
      {
        "name": "Skull Bash",
        "cost": [
          "Metal",
          "Metal",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 4,
        "damage": "140",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "93",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      208
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/93.png",
      "large": "https://images.pokemontcg.io/me1/93_hires.png"
    }
  },
  {
    "id": "me1-94",
    "name": "Mega Mawile ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "270",
    "types": [
      "Metal"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Gobble Down",
        "cost": [
          "Metal",
          "Metal"
        ],
        "convertedEnergyCost": 2,
        "damage": "80×",
        "text": "This attack does 80 damage for each Prize card you have taken."
      },
      {
        "name": "Huge Bite",
        "cost": [
          "Metal",
          "Metal",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "260",
        "text": "If your opponent's Active Pokémon already has any damage counters on it, this attack's base damage is 30."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "94",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      303
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/94.png",
      "large": "https://images.pokemontcg.io/me1/94_hires.png"
    }
  },
  {
    "id": "me1-95",
    "name": "Dialga",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "140",
    "types": [
      "Metal"
    ],
    "attacks": [
      {
        "name": "Beam",
        "cost": [
          "Metal"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": ""
      },
      {
        "name": "Chrono Burst",
        "cost": [
          "Metal",
          "Metal",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "80+",
        "text": "You may shuffle all Energy attached to this Pokémon into your deck and have this attack do 80 more damage."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "95",
    "rarity": "Rare",
    "nationalPokedexNumbers": [
      483
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/95.png",
      "large": "https://images.pokemontcg.io/me1/95_hires.png"
    }
  },
  {
    "id": "me1-96",
    "name": "Tinkatink",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Metal"
    ],
    "attacks": [
      {
        "name": "Beat",
        "cost": [
          "Metal"
        ],
        "convertedEnergyCost": 1,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "96",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      957
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/96.png",
      "large": "https://images.pokemontcg.io/me1/96_hires.png"
    }
  },
  {
    "id": "me1-97",
    "name": "Tinkatuff",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "90",
    "types": [
      "Metal"
    ],
    "evolvesFrom": "Tinkatink",
    "abilities": [
      {
        "name": "Haphazard Hammer",
        "text": "Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Flip a coin. If heads, discard an Energy from your opponent's Active Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Light Punch",
        "cost": [
          "Metal"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "97",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      958
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/97.png",
      "large": "https://images.pokemontcg.io/me1/97_hires.png"
    }
  },
  {
    "id": "me1-98",
    "name": "Tinkaton",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "160",
    "types": [
      "Metal"
    ],
    "evolvesFrom": "Tinkatuff",
    "attacks": [
      {
        "name": "Windup Swing",
        "cost": [
          "Metal"
        ],
        "convertedEnergyCost": 1,
        "damage": "240-",
        "text": "This attack does 60 less damage for each Energy attached to your opponent's Active Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "98",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      959
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/98.png",
      "large": "https://images.pokemontcg.io/me1/98_hires.png"
    }
  },
  {
    "id": "me1-99",
    "name": "Gholdengo",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "130",
    "types": [
      "Metal"
    ],
    "evolvesFrom": "Gimmighoul",
    "attacks": [
      {
        "name": "All-You-Can-Grab",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Flip a coin until you get tails. Search your deck for a number of cards up to the number of heads and put them into your hand. Then, shuffle your deck."
      },
      {
        "name": "Speed Attack",
        "cost": [
          "Metal",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "100",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "99",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      1000
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/99.png",
      "large": "https://images.pokemontcg.io/me1/99_hires.png"
    }
  },
  {
    "id": "me1-100",
    "name": "Mega Latias ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "280",
    "types": [
      "Dragon"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Strafe",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "40",
        "text": "You may switch this Pokémon with 1 of your Benched Pokémon."
      },
      {
        "name": "Illusory Impulse",
        "cost": [
          "Fire",
          "Psychic",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "300",
        "text": "Discard all Energy from this Pokémon."
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "100",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      380
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/100.png",
      "large": "https://images.pokemontcg.io/me1/100_hires.png"
    }
  },
  {
    "id": "me1-101",
    "name": "Latios",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "130",
    "types": [
      "Dragon"
    ],
    "abilities": [
      {
        "name": "Lustrous Assist",
        "text": "Once during your turn, when your Mega Latias ex moves from your Bench to the Active Spot, you may use this Ability. Move any amount of Energy from your Benched Pokémon to your Active Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Dragon Claw",
        "cost": [
          "Water",
          "Psychic",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "130",
        "text": ""
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "101",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      381
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/101.png",
      "large": "https://images.pokemontcg.io/me1/101_hires.png"
    }
  },
  {
    "id": "me1-102",
    "name": "Spearow",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "60",
    "types": [
      "Colorless"
    ],
    "evolvesTo": [
      "Fearow"
    ],
    "attacks": [
      {
        "name": "Pluck",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": "Before doing damage, discard all Pokémon Tools from your opponent's Active Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "102",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      21
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/102.png",
      "large": "https://images.pokemontcg.io/me1/102_hires.png"
    }
  },
  {
    "id": "me1-103",
    "name": "Fearow",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "100",
    "types": [
      "Colorless"
    ],
    "evolvesFrom": "Spearow",
    "attacks": [
      {
        "name": "Repeating Drill",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "30×",
        "text": "Flip 5 coins. This attack does 30 damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "103",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      22
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/103.png",
      "large": "https://images.pokemontcg.io/me1/103_hires.png"
    }
  },
  {
    "id": "me1-104",
    "name": "Mega Kangaskhan ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "300",
    "types": [
      "Colorless"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "abilities": [
      {
        "name": "Run Errand",
        "text": "Once during your turn, if this Pokémon is in the Active Spot, you may use this Ability. Draw 2 cards. You can't use more than 1 Run Errand Ability each turn.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Rapid-Fire Combo",
        "cost": [
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "200+",
        "text": "Flip a coin until you get tails. This attack does 50 more damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "104",
    "rarity": "Double Rare",
    "nationalPokedexNumbers": [
      115
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/104.png",
      "large": "https://images.pokemontcg.io/me1/104_hires.png"
    }
  },
  {
    "id": "me1-105",
    "name": "Delibird",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "90",
    "types": [
      "Colorless"
    ],
    "attacks": [
      {
        "name": "Quick Gift",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "If you go first, you can use this attack during your first turn. Search your deck for a card and put it into your hand. Then, shuffle your deck."
      },
      {
        "name": "Gentle Slap",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "105",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      225
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/105.png",
      "large": "https://images.pokemontcg.io/me1/105_hires.png"
    }
  },
  {
    "id": "me1-106",
    "name": "Miltank",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "120",
    "types": [
      "Colorless"
    ],
    "attacks": [
      {
        "name": "Bellyful of Milk",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "",
        "text": "Flip 2 coins. If both of them are heads, heal all damage from 1 of your Pokémon."
      },
      {
        "name": "Tackle",
        "cost": [
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "60",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "106",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      241
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/106.png",
      "large": "https://images.pokemontcg.io/me1/106_hires.png"
    }
  },
  {
    "id": "me1-107",
    "name": "Buneary",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Colorless"
    ],
    "evolvesTo": [
      "Lopunny"
    ],
    "attacks": [
      {
        "name": "Charm",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "During your opponent's next turn, attacks used by the Defending Pokémon do 20 less damage (before applying Weakness and Resistance)."
      },
      {
        "name": "Skip",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "107",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      427
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/107.png",
      "large": "https://images.pokemontcg.io/me1/107_hires.png"
    }
  },
  {
    "id": "me1-108",
    "name": "Lopunny",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "110",
    "types": [
      "Colorless"
    ],
    "evolvesFrom": "Buneary",
    "attacks": [
      {
        "name": "Dashing Kick",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "This attack does 50 damage to 1 of your opponent's Benched Pokémon. (Don't apply Weakness and Resistance for Benched Pokémon.)"
      },
      {
        "name": "Spiral Kick",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "60",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "108",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      428
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/108.png",
      "large": "https://images.pokemontcg.io/me1/108_hires.png"
    }
  },
  {
    "id": "me1-109",
    "name": "Yungoos",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Colorless"
    ],
    "evolvesTo": [
      "Gumshoos"
    ],
    "attacks": [
      {
        "name": "Collect",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Draw a card."
      },
      {
        "name": "Gnaw",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "109",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      734
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/109.png",
      "large": "https://images.pokemontcg.io/me1/109_hires.png"
    }
  },
  {
    "id": "me1-110",
    "name": "Gumshoos",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "100",
    "types": [
      "Colorless"
    ],
    "evolvesFrom": "Yungoos",
    "abilities": [
      {
        "name": "Evidence Gathering",
        "text": "Once during your turn, you may use this Ability. Switch a card from your hand with the top card of your deck.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Bite",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "110",
    "rarity": "Uncommon",
    "nationalPokedexNumbers": [
      735
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/110.png",
      "large": "https://images.pokemontcg.io/me1/110_hires.png"
    }
  },
  {
    "id": "me1-111",
    "name": "Stufful",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Colorless"
    ],
    "evolvesTo": [
      "Bewear"
    ],
    "attacks": [
      {
        "name": "Light Punch",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Flop",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "111",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      759
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/111.png",
      "large": "https://images.pokemontcg.io/me1/111_hires.png"
    }
  },
  {
    "id": "me1-112",
    "name": "Bewear",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "130",
    "types": [
      "Colorless"
    ],
    "evolvesFrom": "Stufful",
    "attacks": [
      {
        "name": "Knuckle Punch",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": ""
      },
      {
        "name": "Hyper Lariat",
        "cost": [
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "100+",
        "text": "Flip 2 coins. If both of them are heads, this attack does 100 more damage."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "112",
    "rarity": "Common",
    "nationalPokedexNumbers": [
      760
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/112.png",
      "large": "https://images.pokemontcg.io/me1/112_hires.png"
    }
  },
  {
    "id": "me1-113",
    "name": "Acerola's Mischief",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "You can use this card only if your opponent has 2 or fewer Prize cards remaining.  Choose 1 of your Pokémon in play. During your opponent's next turn, prevent all damage from and effects of attacks done to that Pokémon by your opponent's Pokémon ex.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "113",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/113.png",
      "large": "https://images.pokemontcg.io/me1/113_hires.png"
    }
  },
  {
    "id": "me1-114",
    "name": "Boss's Orders",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Switch in 1 of your opponent's Benched Pokémon to the Active Spot.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "114",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/114.png",
      "large": "https://images.pokemontcg.io/me1/114_hires.png"
    }
  },
  {
    "id": "me1-115",
    "name": "Energy Switch",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Move a Basic Energy from 1 of your Pokémon to another of your Pokémon.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "115",
    "rarity": "Common",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/115.png",
      "large": "https://images.pokemontcg.io/me1/115_hires.png"
    }
  },
  {
    "id": "me1-116",
    "name": "Fighting Gong",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Search your deck for a Basic Fighting Energy card or a Basic Fighting Pokémon, reveal it, and put it into your hand. Then, shuffle your deck.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "116",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/116.png",
      "large": "https://images.pokemontcg.io/me1/116_hires.png"
    }
  },
  {
    "id": "me1-117",
    "name": "Forest of Vitality",
    "supertype": "Trainer",
    "subtypes": [
      "Stadium"
    ],
    "rules": [
      "Each player's Grass Pokémon can evolve into Grass Pokémon during the turn they play those Pokémon, except during their first turn.",
      "You may play only 1 Stadium card during your turn. Put it next to the Active Spot, and discard it if another Stadium comes into play. A Stadium with the same name can't be played."
    ],
    "number": "117",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/117.png",
      "large": "https://images.pokemontcg.io/me1/117_hires.png"
    }
  },
  {
    "id": "me1-118",
    "name": "Iron Defender",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "During your opponent's next turn, all of your Metal Pokémon take 30 less damage from attacks from your opponent's Pokémon (after applying Weakness and Resistance). (This includes new Pokémon that come into play.)",
      "You may play any number of Item cards during your turn."
    ],
    "number": "118",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/118.png",
      "large": "https://images.pokemontcg.io/me1/118_hires.png"
    }
  },
  {
    "id": "me1-119",
    "name": "Lillie's Determination",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Shuffle your hand into your deck. Then, draw 6 cards. If you have exactly 6 Prize cards remaining, draw 8 cards instead.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "119",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/119.png",
      "large": "https://images.pokemontcg.io/me1/119_hires.png"
    }
  },
  {
    "id": "me1-120",
    "name": "Lt. Surge's Bargain",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Ask your opponent if each player may take a Prize card. If yes, each player takes a Prize card. If no, you draw 4 cards.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "120",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/120.png",
      "large": "https://images.pokemontcg.io/me1/120_hires.png"
    }
  },
  {
    "id": "me1-121",
    "name": "Mega Signal",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Search your deck for a Mega Evolution Pokémon ex, reveal it, and put it into your hand. Then, shuffle your deck.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "121",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/121.png",
      "large": "https://images.pokemontcg.io/me1/121_hires.png"
    }
  },
  {
    "id": "me1-122",
    "name": "Mystery Garden",
    "supertype": "Trainer",
    "subtypes": [
      "Stadium"
    ],
    "rules": [
      "Once during each player's turn, that player may discard an Energy card from their hand in order to draw cards until they have as many cards in their hand as they have Psychic Pokémon in play.",
      "You may play only 1 Stadium card during your turn. Put it next to the Active Spot, and discard it if another Stadium comes into play. A Stadium with the same name can't be played."
    ],
    "number": "122",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/122.png",
      "large": "https://images.pokemontcg.io/me1/122_hires.png"
    }
  },
  {
    "id": "me1-123",
    "name": "Pokémon Center Lady",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Heal 60 damage from 1 of your Pokémon, and it recovers from all Special Conditions.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "123",
    "rarity": "Common",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/123.png",
      "large": "https://images.pokemontcg.io/me1/123_hires.png"
    }
  },
  {
    "id": "me1-124",
    "name": "Premium Power Pro",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "During this turn, attacks used by your Fighting Pokémon do 30 more damage to your opponent's Active Pokémon (before applying Weakness and Resistance).",
      "You may play any number of Item cards during your turn."
    ],
    "number": "124",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/124.png",
      "large": "https://images.pokemontcg.io/me1/124_hires.png"
    }
  },
  {
    "id": "me1-125",
    "name": "Rare Candy",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Choose 1 of your Basic Pokémon in play. If you have a Stage 2 card in your hand that evolves from that Pokémon, put that card onto the Basic Pokémon to evolve it, skipping the Stage 1. You can't use this card during your first turn or on a Basic Pokémon that was put into play this turn.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "125",
    "rarity": "Common",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/125.png",
      "large": "https://images.pokemontcg.io/me1/125_hires.png"
    }
  },
  {
    "id": "me1-126",
    "name": "Repel",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Switch out your opponent's Active Pokémon to the Bench. (Your opponent chooses the new Active Pokémon.)",
      "You may play any number of Item cards during your turn."
    ],
    "number": "126",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/126.png",
      "large": "https://images.pokemontcg.io/me1/126_hires.png"
    }
  },
  {
    "id": "me1-127",
    "name": "Risky Ruins",
    "supertype": "Trainer",
    "subtypes": [
      "Stadium"
    ],
    "rules": [
      "Whenever any player puts a Basic non-Darkness Pokémon onto their Bench during their turn, place 2 damage counters on that Pokémon.",
      "You may play only 1 Stadium card during your turn. Put it next to the Active Spot, and discard it if another Stadium comes into play. A Stadium with the same name can't be played."
    ],
    "number": "127",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/127.png",
      "large": "https://images.pokemontcg.io/me1/127_hires.png"
    }
  },
  {
    "id": "me1-128",
    "name": "Strange Timepiece",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Devolve 1 of your evolved Psychic Pokémon by putting any number of Evolution cards on it into your hand. (That Pokémon can't evolve this turn.)",
      "You may play any number of Item cards during your turn."
    ],
    "number": "128",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/128.png",
      "large": "https://images.pokemontcg.io/me1/128_hires.png"
    }
  },
  {
    "id": "me1-129",
    "name": "Surfing Beach",
    "supertype": "Trainer",
    "subtypes": [
      "Stadium"
    ],
    "rules": [
      "Once during each player's turn, that player may switch their Active Water Pokémon with 1 of their Benched Water Pokémon.",
      "You may play only 1 Stadium card during your turn. Put it next to the Active Spot, and discard it if another Stadium comes into play. A Stadium with the same name can't be played."
    ],
    "number": "129",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/129.png",
      "large": "https://images.pokemontcg.io/me1/129_hires.png"
    }
  },
  {
    "id": "me1-130",
    "name": "Switch",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Switch your Active Pokémon with 1 of your Benched Pokémon.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "130",
    "rarity": "Common",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/130.png",
      "large": "https://images.pokemontcg.io/me1/130_hires.png"
    }
  },
  {
    "id": "me1-131",
    "name": "Ultra Ball",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "You can use this card only if you discard 2 other cards from your hand.  Search your deck for a Pokémon, reveal it, and put it into your hand. Then, shuffle your deck.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "131",
    "rarity": "Common",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/131.png",
      "large": "https://images.pokemontcg.io/me1/131_hires.png"
    }
  },
  {
    "id": "me1-132",
    "name": "Wally's Compassion",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Heal all damage from 1 of your Mega Evolution Pokémon ex. If you healed any damage in this way, put all Energy attached to that Pokémon into your hand.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "132",
    "rarity": "Uncommon",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/132.png",
      "large": "https://images.pokemontcg.io/me1/132_hires.png"
    }
  },
  {
    "id": "me1-133",
    "name": "Bulbasaur",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Grass"
    ],
    "evolvesTo": [
      "Ivysaur"
    ],
    "attacks": [
      {
        "name": "Bind Down",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": "During your opponent's next turn, the Defending Pokémon can't retreat."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "133",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      1
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/133.png",
      "large": "https://images.pokemontcg.io/me1/133_hires.png"
    }
  },
  {
    "id": "me1-134",
    "name": "Ivysaur",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "110",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Bulbasaur",
    "evolvesTo": [
      "Venusaur"
    ],
    "attacks": [
      {
        "name": "Razor Leaf",
        "cost": [
          "Grass",
          "Grass"
        ],
        "convertedEnergyCost": 2,
        "damage": "60",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "134",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      2
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/134.png",
      "large": "https://images.pokemontcg.io/me1/134_hires.png"
    }
  },
  {
    "id": "me1-135",
    "name": "Exeggutor",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "140",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Exeggcute",
    "attacks": [
      {
        "name": "Guard Press",
        "cost": [
          "Grass"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "During your opponent's next turn, this Pokémon takes 30 less damage from attacks (after applying Weakness and Resistance)."
      },
      {
        "name": "Stomping Wood",
        "cost": [
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "60+",
        "text": "This attack does 30 more damage for each Grass Energy attached to this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "135",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      103
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/135.png",
      "large": "https://images.pokemontcg.io/me1/135_hires.png"
    }
  },
  {
    "id": "me1-136",
    "name": "Shuckle",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Grass"
    ],
    "abilities": [
      {
        "name": "Fermented Juice",
        "text": "Once during your turn, if this Pokémon has any Grass Energy attached, you may use this Ability. Heal 30 damage from 1 of your Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Rollout",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "136",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      213
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/136.png",
      "large": "https://images.pokemontcg.io/me1/136_hires.png"
    }
  },
  {
    "id": "me1-137",
    "name": "Ninjask",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "80",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Nincada",
    "evolvesTo": [
      "Shedinja"
    ],
    "abilities": [
      {
        "name": "Cast-Off Shell",
        "text": "Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Search your deck for a Shedinja and put it onto your Bench. Then, shuffle your deck.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "U-turn",
        "cost": [
          "Grass",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "90",
        "text": "Switch this Pokémon with 1 of your Benched Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "number": "137",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      291
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/137.png",
      "large": "https://images.pokemontcg.io/me1/137_hires.png"
    }
  },
  {
    "id": "me1-138",
    "name": "Vulpix",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Fire"
    ],
    "evolvesTo": [
      "Ninetales"
    ],
    "attacks": [
      {
        "name": "Stampede",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Combustion",
        "cost": [
          "Fire",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "138",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      37
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/138.png",
      "large": "https://images.pokemontcg.io/me1/138_hires.png"
    }
  },
  {
    "id": "me1-139",
    "name": "Litleo",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Fire"
    ],
    "evolvesTo": [
      "Pyroar"
    ],
    "attacks": [
      {
        "name": "Flare",
        "cost": [
          "Fire",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "139",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      667
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/139.png",
      "large": "https://images.pokemontcg.io/me1/139_hires.png"
    }
  },
  {
    "id": "me1-140",
    "name": "Snover",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "90",
    "types": [
      "Water"
    ],
    "evolvesTo": [
      "Abomasnow"
    ],
    "attacks": [
      {
        "name": "Beat",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Icy Snow",
        "cost": [
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Metal",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "140",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      459
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/140.png",
      "large": "https://images.pokemontcg.io/me1/140_hires.png"
    }
  },
  {
    "id": "me1-141",
    "name": "Clawitzer",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "130",
    "types": [
      "Water"
    ],
    "evolvesFrom": "Clauncher",
    "abilities": [
      {
        "name": "Fall Back to Reload",
        "text": "Once during your turn, when this Pokémon moves from the Active Spot to your Bench, you may use this Ability. Attach up to 2 Basic Water Energy cards from your hand to this Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Aqua Launcher",
        "cost": [
          "Water",
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 3,
        "damage": "210",
        "text": "Discard all Energy from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "141",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      693
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/141.png",
      "large": "https://images.pokemontcg.io/me1/141_hires.png"
    }
  },
  {
    "id": "me1-142",
    "name": "Inteleon",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "150",
    "types": [
      "Water"
    ],
    "evolvesFrom": "Drizzile",
    "attacks": [
      {
        "name": "Bring Down",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "Choose a Pokémon in play (yours or your opponent's) that has the least HP remaining, except for this Pokémon, and it is Knocked Out."
      },
      {
        "name": "Water Shot",
        "cost": [
          "Water"
        ],
        "convertedEnergyCost": 1,
        "damage": "110",
        "text": "Discard an Energy from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "142",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      818
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/142.png",
      "large": "https://images.pokemontcg.io/me1/142_hires.png"
    }
  },
  {
    "id": "me1-143",
    "name": "Helioptile",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Lightning"
    ],
    "evolvesTo": [
      "Heliolisk"
    ],
    "attacks": [
      {
        "name": "Double Scratch",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10×",
        "text": "Flip 2 coins. This attack does 10 damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "143",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      694
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/143.png",
      "large": "https://images.pokemontcg.io/me1/143_hires.png"
    }
  },
  {
    "id": "me1-144",
    "name": "Shedinja",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "60",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Nincada",
    "abilities": [
      {
        "name": "Fragile Husk",
        "text": "If this Pokémon is Knocked Out by damage from an attack from your opponent's Pokémon ex, your opponent can't take any Prize cards for it.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Damage Beat",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "20×",
        "text": "This attack does 20 damage for each damage counter on your opponent's Active Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "number": "144",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      292
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/144.png",
      "large": "https://images.pokemontcg.io/me1/144_hires.png"
    }
  },
  {
    "id": "me1-145",
    "name": "Houndstone",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "140",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Greavard",
    "attacks": [
      {
        "name": "Horrifying Bite",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "30",
        "text": "Flip a coin until you get tails. For each heads, choose a random card from your opponent's hand. Your opponent reveals those cards and shuffles them into their deck."
      },
      {
        "name": "Hammer In",
        "cost": [
          "Psychic",
          "Psychic",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "130",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "145",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      972
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/145.png",
      "large": "https://images.pokemontcg.io/me1/145_hires.png"
    }
  },
  {
    "id": "me1-146",
    "name": "Marshadow",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "90",
    "types": [
      "Fighting"
    ],
    "attacks": [
      {
        "name": "Shadowy Side Kick",
        "cost": [
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 2,
        "damage": "60",
        "text": "If your opponent's Pokémon is Knocked Out by damage from this attack, during your opponent's next turn, prevent all damage from and effects of attacks done to this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "146",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      802
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/146.png",
      "large": "https://images.pokemontcg.io/me1/146_hires.png"
    }
  },
  {
    "id": "me1-147",
    "name": "Garganacl",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2"
    ],
    "hp": "180",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Naclstack",
    "abilities": [
      {
        "name": "Powerful a-Salt",
        "text": "Attacks used by your Fighting Pokémon do 30 more damage to your opponent's Active Pokémon (before applying Weakness and Resistance).",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Hammer In",
        "cost": [
          "Fighting",
          "Fighting",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "130",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "147",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      934
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/147.png",
      "large": "https://images.pokemontcg.io/me1/147_hires.png"
    }
  },
  {
    "id": "me1-148",
    "name": "Spiritomb",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "80",
    "types": [
      "Darkness"
    ],
    "abilities": [
      {
        "name": "Spiteful Swirl",
        "text": "If your Active Darkness Pokémon is damaged by an attack from your opponent's Pokémon (even if your Active Darkness Pokémon is Knocked Out), place 1 damage counter on the Attacking Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Mountain Breaker",
        "cost": [
          "Darkness"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": "Discard the top card of your opponent's deck."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "148",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      442
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/148.png",
      "large": "https://images.pokemontcg.io/me1/148_hires.png"
    }
  },
  {
    "id": "me1-149",
    "name": "Shroodle",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "60",
    "types": [
      "Darkness"
    ],
    "attacks": [
      {
        "name": "Poison Jab",
        "cost": [
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": "Your opponent's Active Pokémon is now Poisoned."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "149",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      944
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/149.png",
      "large": "https://images.pokemontcg.io/me1/149_hires.png"
    }
  },
  {
    "id": "me1-150",
    "name": "Steelix",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "200",
    "types": [
      "Metal"
    ],
    "evolvesFrom": "Onix",
    "attacks": [
      {
        "name": "Welcoming Tail",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "40+",
        "text": "If you have exactly 6 Prize cards remaining, this attack does 200 more damage."
      },
      {
        "name": "Skull Bash",
        "cost": [
          "Metal",
          "Metal",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 4,
        "damage": "140",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "150",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      208
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/150.png",
      "large": "https://images.pokemontcg.io/me1/150_hires.png"
    }
  },
  {
    "id": "me1-151",
    "name": "Spearow",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "60",
    "types": [
      "Colorless"
    ],
    "evolvesTo": [
      "Fearow"
    ],
    "attacks": [
      {
        "name": "Pluck",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": "Before doing damage, discard all Pokémon Tools from your opponent's Active Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "151",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      21
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/151.png",
      "large": "https://images.pokemontcg.io/me1/151_hires.png"
    }
  },
  {
    "id": "me1-152",
    "name": "Delibird",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "90",
    "types": [
      "Colorless"
    ],
    "attacks": [
      {
        "name": "Quick Gift",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "If you go first, you can use this attack during your first turn. Search your deck for a card and put it into your hand. Then, shuffle your deck."
      },
      {
        "name": "Gentle Slap",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "30",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Lightning",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "152",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      225
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/152.png",
      "large": "https://images.pokemontcg.io/me1/152_hires.png"
    }
  },
  {
    "id": "me1-153",
    "name": "Gumshoos",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1"
    ],
    "hp": "100",
    "types": [
      "Colorless"
    ],
    "evolvesFrom": "Yungoos",
    "abilities": [
      {
        "name": "Evidence Gathering",
        "text": "Once during your turn, you may use this Ability. Switch a card from your hand with the top card of your deck.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Bite",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "50",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "153",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      735
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/153.png",
      "large": "https://images.pokemontcg.io/me1/153_hires.png"
    }
  },
  {
    "id": "me1-154",
    "name": "Stufful",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic"
    ],
    "hp": "70",
    "types": [
      "Colorless"
    ],
    "evolvesTo": [
      "Bewear"
    ],
    "attacks": [
      {
        "name": "Light Punch",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "10",
        "text": ""
      },
      {
        "name": "Flop",
        "cost": [
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "20",
        "text": ""
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "154",
    "rarity": "Illustration Rare",
    "nationalPokedexNumbers": [
      759
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/154.png",
      "large": "https://images.pokemontcg.io/me1/154_hires.png"
    }
  },
  {
    "id": "me1-155",
    "name": "Mega Venusaur ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2",
      "MEGA",
      "ex"
    ],
    "hp": "380",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Ivysaur",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "abilities": [
      {
        "name": "Solar Transfer",
        "text": "As often as you like during your turn, you may use this Ability. Move a Basic Grass Energy from 1 of your Pokémon to another of your Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Jungle Dump",
        "cost": [
          "Grass",
          "Grass",
          "Grass",
          "Grass"
        ],
        "convertedEnergyCost": 4,
        "damage": "240",
        "text": "Heal 30 damage from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "155",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      3
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/155.png",
      "large": "https://images.pokemontcg.io/me1/155_hires.png"
    }
  },
  {
    "id": "me1-156",
    "name": "Mega Camerupt ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "340",
    "types": [
      "Fire"
    ],
    "evolvesFrom": "Numel",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Roasting Heat",
        "cost": [
          "Fire"
        ],
        "convertedEnergyCost": 1,
        "damage": "80+",
        "text": "If your opponent's Active Pokémon is Burned, this attack does 160 more damage."
      },
      {
        "name": "Volcanic Meteor",
        "cost": [
          "Fire",
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 4,
        "damage": "280",
        "text": "Discard 2 Energy from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Water",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "156",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      323
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/156.png",
      "large": "https://images.pokemontcg.io/me1/156_hires.png"
    }
  },
  {
    "id": "me1-157",
    "name": "Mega Abomasnow ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "350",
    "types": [
      "Water"
    ],
    "evolvesFrom": "Snover",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Hammer-lanche",
        "cost": [
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 2,
        "damage": "100×",
        "text": "Discard the top 6 cards of your deck, and this attack does 100 damage for each Basic Water Energy card that you discarded in this way."
      },
      {
        "name": "Frost Barrier",
        "cost": [
          "Water",
          "Water",
          "Water"
        ],
        "convertedEnergyCost": 3,
        "damage": "200",
        "text": "During your opponent's next turn, this Pokémon takes 30 less damage from attacks (after applying Weakness and Resistance)."
      }
    ],
    "weaknesses": [
      {
        "type": "Metal",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "157",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      460
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/157.png",
      "large": "https://images.pokemontcg.io/me1/157_hires.png"
    }
  },
  {
    "id": "me1-158",
    "name": "Mega Manectric ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "330",
    "types": [
      "Lightning"
    ],
    "evolvesFrom": "Electrike",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Flash Ray",
        "cost": [
          "Lightning",
          "Lightning"
        ],
        "convertedEnergyCost": 2,
        "damage": "120",
        "text": "During your opponent's next turn, prevent all damage done to this Pokémon by attacks from Basic Pokémon."
      },
      {
        "name": "Riotous Blasting",
        "cost": [
          "Lightning",
          "Lightning",
          "Lightning"
        ],
        "convertedEnergyCost": 3,
        "damage": "200+",
        "text": "You may discard all Energy from this Pokémon and have this attack do 130 more damage."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "number": "158",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      310
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/158.png",
      "large": "https://images.pokemontcg.io/me1/158_hires.png"
    }
  },
  {
    "id": "me1-159",
    "name": "Mega Gardevoir ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2",
      "MEGA",
      "ex"
    ],
    "hp": "360",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Kirlia",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Overflowing Wishes",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "For each of your Benched Pokémon, search your deck for a Basic Psychic Energy card and attach it to that Pokémon. Then, shuffle your deck."
      },
      {
        "name": "Mega Symphonia",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "50×",
        "text": "This attack does 50 damage for each Psychic Energy attached to all of your Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "159",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      282
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/159.png",
      "large": "https://images.pokemontcg.io/me1/159_hires.png"
    }
  },
  {
    "id": "me1-160",
    "name": "Mega Lucario ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "340",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Riolu",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Aura Jab",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "130",
        "text": "Attach up to 3 Basic Fighting Energy cards from your discard pile to your Benched Pokémon in any way you like."
      },
      {
        "name": "Mega Brave",
        "cost": [
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 2,
        "damage": "270",
        "text": "During your next turn, this Pokémon can't use Mega Brave."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "160",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      448
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/160.png",
      "large": "https://images.pokemontcg.io/me1/160_hires.png"
    }
  },
  {
    "id": "me1-161",
    "name": "Mega Absol ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "280",
    "types": [
      "Darkness"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Terminal Period",
        "cost": [
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "",
        "text": "If your opponent's Active Pokémon has exactly 6 damage counters on it, that Pokémon is Knocked Out."
      },
      {
        "name": "Claw of Darkness",
        "cost": [
          "Darkness",
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "200",
        "text": "Your opponent reveals their hand, and you discard a card you find there."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "161",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      359
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/161.png",
      "large": "https://images.pokemontcg.io/me1/161_hires.png"
    }
  },
  {
    "id": "me1-162",
    "name": "Mega Mawile ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "270",
    "types": [
      "Metal"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Gobble Down",
        "cost": [
          "Metal",
          "Metal"
        ],
        "convertedEnergyCost": 2,
        "damage": "80×",
        "text": "This attack does 80 damage for each Prize card you have taken."
      },
      {
        "name": "Huge Bite",
        "cost": [
          "Metal",
          "Metal",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "260",
        "text": "If your opponent's Active Pokémon already has any damage counters on it, this attack's base damage is 30."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Grass",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "162",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      303
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/162.png",
      "large": "https://images.pokemontcg.io/me1/162_hires.png"
    }
  },
  {
    "id": "me1-163",
    "name": "Mega Latias ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "280",
    "types": [
      "Dragon"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Strafe",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "40",
        "text": "You may switch this Pokémon with 1 of your Benched Pokémon."
      },
      {
        "name": "Illusory Impulse",
        "cost": [
          "Fire",
          "Psychic",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "300",
        "text": "Discard all Energy from this Pokémon."
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "163",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      380
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/163.png",
      "large": "https://images.pokemontcg.io/me1/163_hires.png"
    }
  },
  {
    "id": "me1-164",
    "name": "Mega Kangaskhan ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "300",
    "types": [
      "Colorless"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "abilities": [
      {
        "name": "Run Errand",
        "text": "Once during your turn, if this Pokémon is in the Active Spot, you may use this Ability. Draw 2 cards. You can't use more than 1 Run Errand Ability each turn.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Rapid-Fire Combo",
        "cost": [
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "200+",
        "text": "Flip a coin until you get tails. This attack does 50 more damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "164",
    "rarity": "Ultra Rare",
    "nationalPokedexNumbers": [
      115
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/164.png",
      "large": "https://images.pokemontcg.io/me1/164_hires.png"
    }
  },
  {
    "id": "me1-165",
    "name": "Acerola's Mischief",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "You can use this card only if your opponent has 2 or fewer Prize cards remaining.  Choose 1 of your Pokémon in play. During your opponent's next turn, prevent all damage from and effects of attacks done to that Pokémon by your opponent's Pokémon ex.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "165",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/165.png",
      "large": "https://images.pokemontcg.io/me1/165_hires.png"
    }
  },
  {
    "id": "me1-166",
    "name": "Air Balloon",
    "supertype": "Trainer",
    "subtypes": [
      "Pokémon Tool"
    ],
    "rules": [
      "The Retreat Cost of the Pokémon this card is attached to is ColorlessColorless less.",
      "You may attach any number of Pokémon Tools to your Pokémon during your turn. You may attach only 1 Pokémon Tool to each Pokémon, and it stays attached."
    ],
    "number": "166",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/166.png",
      "large": "https://images.pokemontcg.io/me1/166_hires.png"
    }
  },
  {
    "id": "me1-167",
    "name": "Buddy-Buddy Poffin",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Search your deck for up to 2 Basic Pokémon with 70 HP or less and put them onto your Bench. Then, shuffle your deck.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "167",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "H",
    "images": {
      "small": "https://images.pokemontcg.io/me1/167.png",
      "large": "https://images.pokemontcg.io/me1/167_hires.png"
    }
  },
  {
    "id": "me1-168",
    "name": "Fighting Gong",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Search your deck for a Basic Fighting Energy card or a Basic Fighting Pokémon, reveal it, and put it into your hand. Then, shuffle your deck.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "168",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/168.png",
      "large": "https://images.pokemontcg.io/me1/168_hires.png"
    }
  },
  {
    "id": "me1-169",
    "name": "Lillie's Determination",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Shuffle your hand into your deck. Then, draw 6 cards. If you have exactly 6 Prize cards remaining, draw 8 cards instead.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "169",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/169.png",
      "large": "https://images.pokemontcg.io/me1/169_hires.png"
    }
  },
  {
    "id": "me1-170",
    "name": "Lt. Surge's Bargain",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Ask your opponent if each player may take a Prize card. If yes, each player takes a Prize card. If no, you draw 4 cards.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "170",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/170.png",
      "large": "https://images.pokemontcg.io/me1/170_hires.png"
    }
  },
  {
    "id": "me1-171",
    "name": "Mega Signal",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Search your deck for a Mega Evolution Pokémon ex, reveal it, and put it into your hand. Then, shuffle your deck.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "171",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/171.png",
      "large": "https://images.pokemontcg.io/me1/171_hires.png"
    }
  },
  {
    "id": "me1-172",
    "name": "Mystery Garden",
    "supertype": "Trainer",
    "subtypes": [
      "Stadium"
    ],
    "rules": [
      "Once during each player's turn, that player may discard an Energy card from their hand in order to draw cards until they have as many cards in their hand as they have Psychic Pokémon in play.",
      "You may play only 1 Stadium card during your turn. Put it next to the Active Spot, and discard it if another Stadium comes into play. A Stadium with the same name can't be played."
    ],
    "number": "172",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/172.png",
      "large": "https://images.pokemontcg.io/me1/172_hires.png"
    }
  },
  {
    "id": "me1-173",
    "name": "Night Stretcher",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Put a Pokémon or a Basic Energy card from your discard pile into your hand.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "173",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "H",
    "images": {
      "small": "https://images.pokemontcg.io/me1/173.png",
      "large": "https://images.pokemontcg.io/me1/173_hires.png"
    }
  },
  {
    "id": "me1-174",
    "name": "Premium Power Pro",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "During this turn, attacks used by your Fighting Pokémon do 30 more damage to your opponent's Active Pokémon (before applying Weakness and Resistance).",
      "You may play any number of Item cards during your turn."
    ],
    "number": "174",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/174.png",
      "large": "https://images.pokemontcg.io/me1/174_hires.png"
    }
  },
  {
    "id": "me1-175",
    "name": "Rare Candy",
    "supertype": "Trainer",
    "subtypes": [
      "Item"
    ],
    "rules": [
      "Choose 1 of your Basic Pokémon in play. If you have a Stage 2 card in your hand that evolves from that Pokémon, put that card onto the Basic Pokémon to evolve it, skipping the Stage 1. You can't use this card during your first turn or on a Basic Pokémon that was put into play this turn.",
      "You may play any number of Item cards during your turn."
    ],
    "number": "175",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/175.png",
      "large": "https://images.pokemontcg.io/me1/175_hires.png"
    }
  },
  {
    "id": "me1-176",
    "name": "Wally's Compassion",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Heal all damage from 1 of your Mega Evolution Pokémon ex. If you healed any damage in this way, put all Energy attached to that Pokémon into your hand.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "176",
    "rarity": "Ultra Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/176.png",
      "large": "https://images.pokemontcg.io/me1/176_hires.png"
    }
  },
  {
    "id": "me1-177",
    "name": "Mega Venusaur ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2",
      "MEGA",
      "ex"
    ],
    "hp": "380",
    "types": [
      "Grass"
    ],
    "evolvesFrom": "Ivysaur",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "abilities": [
      {
        "name": "Solar Transfer",
        "text": "As often as you like during your turn, you may use this Ability. Move a Basic Grass Energy from 1 of your Pokémon to another of your Pokémon.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Jungle Dump",
        "cost": [
          "Grass",
          "Grass",
          "Grass",
          "Grass"
        ],
        "convertedEnergyCost": 4,
        "damage": "240",
        "text": "Heal 30 damage from this Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Fire",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 4,
    "number": "177",
    "rarity": "Special Illustration Rare",
    "nationalPokedexNumbers": [
      3
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/177.png",
      "large": "https://images.pokemontcg.io/me1/177_hires.png"
    }
  },
  {
    "id": "me1-178",
    "name": "Mega Gardevoir ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2",
      "MEGA",
      "ex"
    ],
    "hp": "360",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Kirlia",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Overflowing Wishes",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "For each of your Benched Pokémon, search your deck for a Basic Psychic Energy card and attach it to that Pokémon. Then, shuffle your deck."
      },
      {
        "name": "Mega Symphonia",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "50×",
        "text": "This attack does 50 damage for each Psychic Energy attached to all of your Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "178",
    "rarity": "Special Illustration Rare",
    "nationalPokedexNumbers": [
      282
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/178.png",
      "large": "https://images.pokemontcg.io/me1/178_hires.png"
    }
  },
  {
    "id": "me1-179",
    "name": "Mega Lucario ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "340",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Riolu",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Aura Jab",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "130",
        "text": "Attach up to 3 Basic Fighting Energy cards from your discard pile to your Benched Pokémon in any way you like."
      },
      {
        "name": "Mega Brave",
        "cost": [
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 2,
        "damage": "270",
        "text": "During your next turn, this Pokémon can't use Mega Brave."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "179",
    "rarity": "Special Illustration Rare",
    "nationalPokedexNumbers": [
      448
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/179.png",
      "large": "https://images.pokemontcg.io/me1/179_hires.png"
    }
  },
  {
    "id": "me1-180",
    "name": "Mega Absol ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "280",
    "types": [
      "Darkness"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Terminal Period",
        "cost": [
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 2,
        "damage": "",
        "text": "If your opponent's Active Pokémon has exactly 6 damage counters on it, that Pokémon is Knocked Out."
      },
      {
        "name": "Claw of Darkness",
        "cost": [
          "Darkness",
          "Darkness",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "200",
        "text": "Your opponent reveals their hand, and you discard a card you find there."
      }
    ],
    "weaknesses": [
      {
        "type": "Grass",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "180",
    "rarity": "Special Illustration Rare",
    "nationalPokedexNumbers": [
      359
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/180.png",
      "large": "https://images.pokemontcg.io/me1/180_hires.png"
    }
  },
  {
    "id": "me1-181",
    "name": "Mega Latias ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "280",
    "types": [
      "Dragon"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Strafe",
        "cost": [
          "Colorless"
        ],
        "convertedEnergyCost": 1,
        "damage": "40",
        "text": "You may switch this Pokémon with 1 of your Benched Pokémon."
      },
      {
        "name": "Illusory Impulse",
        "cost": [
          "Fire",
          "Psychic",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "300",
        "text": "Discard all Energy from this Pokémon."
      }
    ],
    "retreatCost": [
      "Colorless"
    ],
    "convertedRetreatCost": 1,
    "number": "181",
    "rarity": "Special Illustration Rare",
    "nationalPokedexNumbers": [
      380
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/181.png",
      "large": "https://images.pokemontcg.io/me1/181_hires.png"
    }
  },
  {
    "id": "me1-182",
    "name": "Mega Kangaskhan ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Basic",
      "MEGA",
      "ex"
    ],
    "hp": "300",
    "types": [
      "Colorless"
    ],
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "abilities": [
      {
        "name": "Run Errand",
        "text": "Once during your turn, if this Pokémon is in the Active Spot, you may use this Ability. Draw 2 cards. You can't use more than 1 Run Errand Ability each turn.",
        "type": "Ability"
      }
    ],
    "attacks": [
      {
        "name": "Rapid-Fire Combo",
        "cost": [
          "Colorless",
          "Colorless",
          "Colorless"
        ],
        "convertedEnergyCost": 3,
        "damage": "200+",
        "text": "Flip a coin until you get tails. This attack does 50 more damage for each heads."
      }
    ],
    "weaknesses": [
      {
        "type": "Fighting",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 3,
    "number": "182",
    "rarity": "Special Illustration Rare",
    "nationalPokedexNumbers": [
      115
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/182.png",
      "large": "https://images.pokemontcg.io/me1/182_hires.png"
    }
  },
  {
    "id": "me1-183",
    "name": "Acerola's Mischief",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "You can use this card only if your opponent has 2 or fewer Prize cards remaining.  Choose 1 of your Pokémon in play. During your opponent's next turn, prevent all damage from and effects of attacks done to that Pokémon by your opponent's Pokémon ex.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "183",
    "rarity": "Special Illustration Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/183.png",
      "large": "https://images.pokemontcg.io/me1/183_hires.png"
    }
  },
  {
    "id": "me1-184",
    "name": "Lillie's Determination",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Shuffle your hand into your deck. Then, draw 6 cards. If you have exactly 6 Prize cards remaining, draw 8 cards instead.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "184",
    "rarity": "Special Illustration Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/184.png",
      "large": "https://images.pokemontcg.io/me1/184_hires.png"
    }
  },
  {
    "id": "me1-185",
    "name": "Lt. Surge's Bargain",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Ask your opponent if each player may take a Prize card. If yes, each player takes a Prize card. If no, you draw 4 cards.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "185",
    "rarity": "Special Illustration Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/185.png",
      "large": "https://images.pokemontcg.io/me1/185_hires.png"
    }
  },
  {
    "id": "me1-186",
    "name": "Wally's Compassion",
    "supertype": "Trainer",
    "subtypes": [
      "Supporter"
    ],
    "rules": [
      "Heal all damage from 1 of your Mega Evolution Pokémon ex. If you healed any damage in this way, put all Energy attached to that Pokémon into your hand.",
      "You may play only 1 Supporter card during your turn."
    ],
    "number": "186",
    "rarity": "Special Illustration Rare",
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/186.png",
      "large": "https://images.pokemontcg.io/me1/186_hires.png"
    }
  },
  {
    "id": "me1-187",
    "name": "Mega Gardevoir ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 2",
      "MEGA",
      "ex"
    ],
    "hp": "360",
    "types": [
      "Psychic"
    ],
    "evolvesFrom": "Kirlia",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Overflowing Wishes",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "",
        "text": "For each of your Benched Pokémon, search your deck for a Basic Psychic Energy card and attach it to that Pokémon. Then, shuffle your deck."
      },
      {
        "name": "Mega Symphonia",
        "cost": [
          "Psychic"
        ],
        "convertedEnergyCost": 1,
        "damage": "50×",
        "text": "This attack does 50 damage for each Psychic Energy attached to all of your Pokémon."
      }
    ],
    "weaknesses": [
      {
        "type": "Darkness",
        "value": "×2"
      }
    ],
    "resistances": [
      {
        "type": "Fighting",
        "value": "-30"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "187",
    "rarity": "Mega Hyper Rare",
    "nationalPokedexNumbers": [
      282
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/187.png",
      "large": "https://images.pokemontcg.io/me1/187_hires.png"
    }
  },
  {
    "id": "me1-188",
    "name": "Mega Lucario ex",
    "supertype": "Pokémon",
    "subtypes": [
      "Stage 1",
      "MEGA",
      "ex"
    ],
    "hp": "340",
    "types": [
      "Fighting"
    ],
    "evolvesFrom": "Riolu",
    "rules": [
      "Mega Evolution ex Rule: When your Mega Evolution Pokémon ex is Knocked Out, your opponent takes 3 Prize cards."
    ],
    "attacks": [
      {
        "name": "Aura Jab",
        "cost": [
          "Fighting"
        ],
        "convertedEnergyCost": 1,
        "damage": "130",
        "text": "Attach up to 3 Basic Fighting Energy cards from your discard pile to your Benched Pokémon in any way you like."
      },
      {
        "name": "Mega Brave",
        "cost": [
          "Fighting",
          "Fighting"
        ],
        "convertedEnergyCost": 2,
        "damage": "270",
        "text": "During your next turn, this Pokémon can't use Mega Brave."
      }
    ],
    "weaknesses": [
      {
        "type": "Psychic",
        "value": "×2"
      }
    ],
    "retreatCost": [
      "Colorless",
      "Colorless"
    ],
    "convertedRetreatCost": 2,
    "number": "188",
    "rarity": "Mega Hyper Rare",
    "nationalPokedexNumbers": [
      448
    ],
    "legalities": {
      "unlimited": "Legal",
      "standard": "Legal",
      "expanded": "Legal"
    },
    "regulationMark": "I",
    "images": {
      "small": "https://images.pokemontcg.io/me1/188.png",
      "large": "https://images.pokemontcg.io/me1/188_hires.png"
    }
  }
];